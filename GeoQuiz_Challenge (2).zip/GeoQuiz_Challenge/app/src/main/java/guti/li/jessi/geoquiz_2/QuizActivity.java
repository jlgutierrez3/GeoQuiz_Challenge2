package guti.li.jessi.geoquiz_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


/*AppCompatActivity is a subclass of Android's Activity class that
  provides compatibility support for older
  versions of Android
*/
public class QuizActivity extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;
    private ImageButton mNextButton;
    private ImageButton mPreviousButton;

    private TextView mQuestionTextView;


    private Question[] mQuestionBank = new Question[]{
            new Question(R.string.question_australia, true),
            new Question(R.string.question_oceans, true),
            new Question(R.string.question_mideast, false),
            new Question(R.string.question_africa, false),
            new Question(R.string.question_americas, true),
            new Question(R.string.question_asia, true),
    };


    private int mCurrentIndex = 0;


    /*  These were created unnecessarily?
        public QuizActivity(Button mTrueButton) {
        this.mTrueButton = mTrueButton;
        }
        public QuizActivity(Button mFalseButton) {
        this.mFalseButton = mFalseButton;
        }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        mQuestionTextView = (TextView)
                findViewById(R.id.question_text_view);
        //This is where the solutions were posting their code.
                //int question = mQuestionBank[mCurrentIndex].getTextResId();
                //mQuestionTextView.setText(question);

                mQuestionTextView.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View V){
                        mCurrentIndex = (mCurrentIndex+1)%mQuestionBank.length;
                        updateQuestion();
                    }
                });



        mTrueButton = (Button) findViewById(R.id.true_button);
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
            }
        });



        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener()  {
            @Override
                public void onClick(View v) {
                    checkAnswer(false);
            }
        });


        mNextButton = (ImageButton) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
                //int question = mQuestionBank[mCurrentIndex].getTextResId();
                //mQuestionTextView.setText(question);
                updateQuestion();
            }
        });
        updateQuestion();

        mPreviousButton = (ImageButton) findViewById(R.id.previous_button);
        mPreviousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notZero();
                mCurrentIndex =(mCurrentIndex - 1) % mQuestionBank.length;
                updateQuestion();
            }
        });

    }
    //This was thought up by Darrin
    //create a method, let Toast t be the input
    //Add a way to Get the length and make it global
    //calculate the relative length away from the y axis top that you want
    private void toastPlacement(Toast t) {
        t.setGravity(Gravity.TOP,0,400);
        t.show();
    }

    //Added to prevent the mQuestionBank array from going negative.
    private void notZero(){
        if(mCurrentIndex == 0){
            mCurrentIndex = mQuestionBank.length;
        }
    }

    private void updateQuestion() {
        int question = mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();

        int messageResId = 0;

        if (userPressedTrue == answerIsTrue) {
            messageResId = R.string.correct_toast;
        } else {
            messageResId = R.string.incorrect_toast;
        }
        Toast toast =
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT);
        toastPlacement(toast);
    }




}
